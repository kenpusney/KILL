/* global List, Tuple, id, trace */
/* global kill */

/**
 * Created by Kim on 2014/8/1.
 */
 kill.compiler = (function (kill) {

     var Lambda = function (argc, argv, body) {
         this.argc = argc;
         this.argv = argv;
         this.body = body;
         this.merge = function (lmbd) {
             return new Lambda(argc + lmbd.argc, argv.concat(lmbd.argv), lmbd.body);
         };
     };

     var Binding = function (name, val) {
         this.name = name;
         this.val = val;
     };

     var Bindings = function (bindings) {
         this.bindings = bindings;
         this.append = function (binding) {
             this.bindings.push(binding);
             return this;
         };
     };

     var FCall = function (name, args) {
         this.name = name;
         this.args = args;
     };

     var If = function (cond, consequence, alternative) {
         this.cond = cond;
         this.consequence = consequence;
         this.alternative = alternative;
     };

     var Statements = function (stmts) {
         stmts = stmts || [];
         this.append = function (stmt) {
             stmts.push(stmt);
             return this;
         };
         this.count = function () {
             return stmts.length;
         };
         this.get = function (index) {
             return stmts[index];
         };
     };

     function nameof(id) {
       if(id.accessor.length) {
         return id.object + '.' + accessor.join(".");
       } else {
         return id.object;
       }
     }

    handlers = {
      "let": function (form, ctx) {
        var bindings = form.value;
        var bindres = new Bindings([]);
        for (var i = 0; i < bindings.length; i++) {
            bindres.append(new Binding(transform(bindings[i][0]),
                transform(bindings[i][1], id)));
        }
        console.log(bindres);
        return ctx(bindres)
      },
      "lambda": function (form, ctx) {
        var param = form.value.params;
        var body = form.value.body;
        console.log(param);
        var lambda = new Lambda(param.length, param, null);
        return transform(body, function (bdy) {
            lambda.body = bdy;
            return ctx(lambda);
        });
      },
      "if": function (form, ctx) {
        var cond = form.value.test;
        var consequence = form.value.consequence;
        var alternative = form.value.alternative;
        return ctx(
            new If(
                transform(cond, id),
                transform(consequence, id),
                transform(alternative, id))
            );
      },
      "begin": function (form, ctx) {
        var begins = form.slice(1);
        var stmts = [];
        for (i = 0; i < begins.length; i++) {
            stmts.push(dump(transform(begins[i], id), id));
        }
        return ctx(new Statements(stmts));
      },
      "quote": function (form, ctx) {
        return ctx(form[1]);
      },
      "set!": function (form, ctx) {
        var atom = form[1];
        var expr = form[2];
        return ctx([atom, "=", dump(transform(expr, id), id)].join(" "));
      },
      "list": function (form, ctx) {
        var lst = [];
        for (i = 0; i < form[1].length; i++) {
            lst.push(transform(form[1][i], id));
        }
        return ctx(new List(lst));
      },
      "tuple": function (form, ctx) {
        var tup = form[1][1];
        var tuple = [];
        for (i = 0; i < tup.length; i++) {
            tuple.push(transform(tup[i], id));
        }
        return ctx(new Tuple(tuple));
      },
      "list_comp": function (form, ctx) {
        var list = form[1];
        var comp = form[2];
        return ctx("_$$comprehension(" + dump(transform(new List(list.map(function (arg) {
            return transform(arg[1], id);
        })), id), id) + ", " + dump(transform(comp, id), id) + ")");
      },
      "id": function (form, ctx) {
        return ctx(nameof(form.value));
      }
    }
     var transform = function (form, ctx) {
         ctx = ctx || trace;
         console.log(form);
         if (form.tag) {
             if (handlers[form.tag]) {
               return handlers[form.tag](form, ctx);
             }
             return transform(form[0], function (fn) {
                 if (form.slice(1).length) {
                     if (fn instanceof FCall) {
                         return ctx(new FCall(fn, transform(form.slice(1), id)));
                     } else {
                         return ctx(new FCall(fn, transform(form.slice(1), id)));
                     }
                 }
                 return ctx(fn);
             });
         }
         if (typeof (form) == "string") {
             /**
              * @TODO:
              * Syntax Translation:
              *      ? => $q_
              *      ! => $e_
              *      ...
              * */
             form.replace(/\?/g, "$q_");
             form.replace(/!/g, "$e_");
             return ctx(form);
         }
         return ctx(form);
     };

     var dumpName = function (ctx) {
       return function (ids) {
         return ctx(ids.map(function (id) {
           return nameof(id.value);
         }).join(", "));
       }
     }

     var extractValue = function (ctx) {
       return function (obj) {
         if (obj.length == 1 && obj instanceof Array) {
           return extractValue(ctx)(obj[0]);
         }
         if (obj.value) {
           return ctx(obj.value);
         } else {
           return dump(obj, ctx);
         }
       }
     }

     var dump = function (form, ctx) {
         ctx = ctx || trace;
         if (form instanceof Statements) {
             var stmts = [];
             for (var i = 0; i < form.count(); i++) {
                 if ((form.get(i) instanceof Array) && form.get(i).length)
                     continue;
                 if (i == form.count() - 1) {
                     stmts.push("return " + dump(form.get(i), id));
                 } else {
                     stmts.push(dump(form.get(i), id));
                 }
             }
             return ctx("(function(){" + stmts.join(";\n") + "}());");
         }
         if (form instanceof Lambda)
             return ctx("(function(" + dump(form.argv, dumpName(ctx)) + "){ return " + dump(form.body, id) + ";})");
         else if (form instanceof If) {
             return ctx("( " + dump(form.cond, id) + " ) ? " +
                 "( " + dump(form.consequence, id) + " )" +
                 ":" +
                 "( " + dump(form.alternative, id) + " )");
         }
         else if (form instanceof FCall) {
           console.log(form);
             return dump(form.args, function (args) {
                 return ctx(dump(form.name, id) + "(" + args + ")");
             });
         } else if (form instanceof Bindings) {
             return ctx("var " + form.bindings.map(function (binding) {
                 return binding.name + "=" + dump(binding.val, extractValue(ctx));
             }).join(', '));
         } else if (form instanceof List) {
             var lst = [];
             for (i = 0; i < form.list.length; i++) {
                 lst.push(dump(form.list[i], id));
             }
             return ctx("[" + lst.join(", ") + "]");
         } else if (form instanceof Tuple) {
             var tup = [];
             for (i = 0; i < form.size(); i++) {
                 tup.push(dump(form.get(i), id));
             }
             return ctx("tuple(" + tup.join(", ") + ")");
         }
         return ctx(form);
     };

     var compile = function (tree) {
         var stmts = new Statements([]);
         for (var i = 0; i < tree.length; i++) {
             stmts.append(transform(tree[i], id));
         }
         return dump(stmts, id);
     };

     kill.compiler = {
         dump: dump,
         transform: transform,
         compile: compile,
         Lambda: Lambda,
         FCall: FCall,
         Binding: Binding
     };
     return kill.compiler;
 } (kill));
